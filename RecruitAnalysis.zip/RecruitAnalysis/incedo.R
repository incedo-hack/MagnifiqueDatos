library(ggplot2)
library(dplyr)
library(reshape)

setwd("D://RecruitFinalFinal")
data3<-read.csv("WA_Fn-UseC_-HR-Employee-Acceptance.csv")
dfAccept<-data3
dfplot <- function(data.frame)
{
  df <- data.frame
  ln <- length(names(data.frame))
  for(i in 1:ln){
    mname <- substitute(df[,i])
    if(is.factor(df[,i])) {
      plot(df[,i],main=names(df)[i])
    } else { 
      hist(df[,i],main=names(df)[i])
    }
  }
}
par(mfrow=c(3,3),mar=c(2,1,1,1)) #my example has 9 columns
dfplot(dfAccept)
set.seed(56789)
dfAccept$Age<-as.factor(dfAccept$Age)
dfAccept<-subset(data3, (Age >= 20 & Age <=35))
write.csv(dfAccept, "FinalData.csv")
acceptByIncomeGrp<-group_by(dfAccept, Acceptance,Age) 
acceptByAge<-summarise(acceptByIncomeGrp, mean_income=mean(MonthlyIncome),
                             median_income=median(MonthlyIncome),
                             min_income=min(MonthlyIncome),
                             max_income=max(MonthlyIncome),
                             n=n())
write.csv(acceptByAge, "FinalMeanData.csv")
ggplot(dfAccept, aes(x=Acceptance, y=MonthlyIncome)) + geom_boxplot()
paste(colnames(dfAccept), sep = ", ", collapse = "','")
paste(colnames(dfAccept), sep = "+", collapse = "+")
cor(dfAccept[,unlist(lapply(dfAccept, is.numeric))])
ggplot(acceptByAge, aes(x=Age, y=mean_income, color=Acceptance)) + geom_line() +
  scale_x_continuous(breaks = seq(20,40, 2)) + scale_y_continuous(breaks = seq(2000,40000, 1000)) +
ylab("Income")  
